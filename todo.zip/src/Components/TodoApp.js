import React, { useState, useEffect } from "react";

function TodoApp() {
  const [task, setTask] = useState("");
  const [tasklist, setTaskList] = useState([]);
  const [user, setUser] = useState({});

  const handleChange = (e) => {
    setTask(e.target.value);
  };

  useEffect(()=>{

    setUser(JSON.parse(localStorage.getItem('user')));

  }, []);

  const AddTask = () => {
    if (task !== "") {
      const taskDetails = {
        id: Math.floor(Math.random() * 1000),
        value: task,
        isCompleted: false,
      };
      setTaskList([...tasklist, taskDetails]);
    }
  
  };

  const deletetask = (e, id) => {
    e.preventDefault();
    setTaskList(tasklist.filter((t) => t.id != id));
  };

  const taskCompleted = (e, id) => {
    e.preventDefault();
    
    //let's find index of element
    const element = tasklist.findIndex((elem) => elem.id == id);

    //copy array into new variable
    const newTaskList = [...tasklist];
  
    //edit our element
    newTaskList[element] = {
      ...newTaskList[element],
      isCompleted: true,
    };

    setTaskList(newTaskList);
  };
  const  handleClick = () => {
    console.log("Logout");
    localStorage.removeItem('user');
    window.location.href = '/';
   
  }

  return (
    <React.Fragment>
      <div className="login-nav py-2">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <div class="media">
                <img src={user.image_url} class="mr-3 user-image rounded-circle" alt="User Image" />
                <div class="media-body align-self-center">
                  <h5 class="mt-0">{user.name}</h5>
                </div>
              </div>
            </div>
            <div style={{cursor:"pointer"}} onClick={handleClick}>Logout</div>
          </div>
        </div>
      </div>
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="todo mt-5">
              <input
              type="text"
              name="text"
              className="form-control"
              id="text"
              onChange={(e) => handleChange(e)}
              placeholder="Add task here..."
            />
              <button className="add-btn btn btn-primary mt-3" onClick={AddTask}>
              Add
            </button>
              <br />
            {tasklist !== [] ? (
              
              <div className="row mt-3">
                {tasklist.map((t, index) => (
                  
                <div  key={index} className={`col-md-3 mb-3 ${t.isCompleted ? "crossText" : "listitem"}`}>
                  <div className="border p-3">
                    <h4 className="text-capitalize">{t.value}</h4>
                    <button
                      className="completed btn btn-success mr-2"
                      disabled={t.isCompleted}
                      onClick={(e) => taskCompleted(e, t.id)}
                    >
                      {(t.isCompleted)? 'Completed' : "Complete"}
                    </button>
                    <button className="delete btn btn-danger" onClick={(e) => deletetask(e, t.id)}>
                      Delete
                    </button>
                  </div>
                </div>
                ))}
              
              </div>
            ) : null}
          
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default TodoApp;