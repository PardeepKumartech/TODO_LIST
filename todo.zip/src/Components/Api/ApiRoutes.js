module.exports = {

    loginUser: {
        'method': 'POST',
        'url': 'https://myloginendpoint.free.beeceptor.com/login'
    }
}